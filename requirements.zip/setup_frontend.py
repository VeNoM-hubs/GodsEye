"""
GodsEye — Frontend Setup Script (Windows)
==========================================
AI-Driven IoT Network for Cyber-Physical Threat Detection
github.com/VeNoM-hubs/GodsEye

Run this script ONCE after cloning the repo (backend setup should run first):
    python setup_frontend.py

What this script does (fully automated):
  1.  Checks that Python is available (used to run this script only)
  2.  Downloads & installs Node.js v20 LTS silently via winget or direct MSI
  3.  Installs pnpm v10 globally via npm
  4.  Runs 'pnpm install' inside the frontend/ directory
  5.  Creates frontend/.env from template with correct default values
  6.  Runs 'pnpm typecheck' to verify TypeScript is happy
  7.  Runs 'pnpm build' to verify a clean production build
  8.  Prints a final status report with all dev commands

REQUIREMENTS BEFORE RUNNING:
  - Python 3.10+ already installed  (https://python.org/downloads)
  - Run PowerShell as Administrator  (right-click > Run as Administrator)
  - Internet connection
"""

import os
import sys
import subprocess
import platform
import shutil
import urllib.request
import tempfile
import time
import ctypes
from pathlib import Path

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------

REPO_ROOT      = Path(__file__).parent.resolve()
FRONTEND_DIR   = REPO_ROOT / "frontend"
ENV_EXAMPLE    = FRONTEND_DIR / ".env.example"
ENV_TARGET     = FRONTEND_DIR / ".env"

# Node.js v20 LTS Windows x64 MSI
NODE_VERSION       = "20.15.0"
NODE_MSI_URL       = (
    f"https://nodejs.org/dist/v{NODE_VERSION}/"
    f"node-v{NODE_VERSION}-x64.msi"
)

# pnpm version
PNPM_VERSION       = "10"

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

def banner():
    print(f"""
{CYAN}{BOLD}
╔══════════════════════════════════════════════════════════════╗
║        GodsEye — Frontend Setup Script (Windows)            ║
║   React 18 + TypeScript + Vite + TailwindCSS 3              ║
╚══════════════════════════════════════════════════════════════╝
{RESET}""")

def step(n, total, msg):
    print(f"\n{CYAN}[{n}/{total}]{RESET} {BOLD}{msg}{RESET}")

def ok(msg):
    print(f"  {GREEN}✔{RESET}  {msg}")

def warn(msg):
    print(f"  {YELLOW}⚠{RESET}  {msg}")

def fail(msg):
    print(f"  {RED}✘{RESET}  {msg}")

def run(cmd, check=True, capture=False, cwd=None):
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=capture,
        text=True,
        cwd=cwd or REPO_ROOT
    )
    if check and result.returncode != 0:
        raise RuntimeError(
            f"Command failed (exit {result.returncode}): {cmd}\n"
            f"{result.stderr}"
        )
    return result

def download(url, dest_path, label):
    print(f"  Downloading {label} ...", end="", flush=True)
    def reporthook(count, block_size, total_size):
        if total_size > 0:
            pct = min(int(count * block_size * 100 / total_size), 100)
            print(f"\r  Downloading {label} ... {pct}%", end="", flush=True)
    urllib.request.urlretrieve(url, dest_path, reporthook)
    print(f"\r  Downloading {label} ... {GREEN}done{RESET}        ")

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def node_version():
    """Return installed Node.js version string or None."""
    r = subprocess.run("node --version", shell=True, capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None

def npm_version():
    r = subprocess.run("npm --version", shell=True, capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None

def pnpm_version():
    r = subprocess.run("pnpm --version", shell=True, capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None

def refresh_path():
    """Reload PATH from registry so newly installed tools are visible."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment") as k:
            sys_path, _ = winreg.QueryValueEx(k, "Path")
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment") as k:
            try:
                usr_path, _ = winreg.QueryValueEx(k, "Path")
            except FileNotFoundError:
                usr_path = ""
        os.environ["PATH"] = sys_path + ";" + usr_path + ";" + os.environ.get("PATH", "")
    except Exception:
        pass  # Non-critical — new shell will have the correct PATH

# ---------------------------------------------------------------------------
# STEPS
# ---------------------------------------------------------------------------

TOTAL_STEPS = 8

def step1_check_prerequisites():
    step(1, TOTAL_STEPS, "Checking prerequisites")
    major, minor = sys.version_info[:2]
    if major < 3 or (major == 3 and minor < 10):
        fail(f"Python 3.10+ required. Found {major}.{minor}")
        sys.exit(1)
    ok(f"Python {major}.{minor} — OK")
    if platform.system() != "Windows":
        fail("This script targets Windows only.")
        sys.exit(1)
    ok("OS: Windows — OK")
    if not FRONTEND_DIR.exists():
        fail(f"frontend/ directory not found at {FRONTEND_DIR}")
        fail("Make sure you are running this from the GodsEye repo root.")
        sys.exit(1)
    ok(f"frontend/ directory found")
    if not (FRONTEND_DIR / "package.json").exists():
        fail("frontend/package.json not found — repo may be incomplete.")
        sys.exit(1)
    ok("frontend/package.json found")
    if not is_admin():
        warn("Not running as Administrator.")
        warn("Node.js MSI install requires admin. Re-run as Administrator if it fails.")

def step2_install_nodejs():
    step(2, TOTAL_STEPS, "Installing Node.js v20 LTS")
    existing = node_version()
    if existing:
        # Check major version >= 18
        try:
            major = int(existing.lstrip("v").split(".")[0])
            if major >= 18:
                ok(f"Node.js {existing} already installed — skipping")
                return
            else:
                warn(f"Node.js {existing} found but v18+ required. Installing v20 LTS ...")
        except ValueError:
            warn(f"Could not parse Node.js version '{existing}'. Re-installing ...")

    # Try winget first (available on Windows 10 1809+, Windows 11)
    winget_check = subprocess.run(
        "winget --version", shell=True, capture_output=True, text=True
    )
    if winget_check.returncode == 0:
        print("  Using winget to install Node.js v20 LTS ...")
        result = run(
            "winget install OpenJS.NodeJS.LTS --version 20.15.0 "
            "--silent --accept-package-agreements --accept-source-agreements",
            check=False
        )
        if result.returncode == 0:
            refresh_path()
            ok(f"Node.js installed via winget")
            return
        warn("winget install failed — falling back to MSI download ...")

    # Fallback: direct MSI download
    if not is_admin():
        fail("Node.js MSI install requires Administrator. Re-run as admin.")
        fail("Or install manually: https://nodejs.org/en/download/")
        sys.exit(1)

    with tempfile.TemporaryDirectory() as tmp:
        msi_path = Path(tmp) / f"node-v{NODE_VERSION}-x64.msi"
        download(NODE_MSI_URL, msi_path, f"Node.js v{NODE_VERSION} LTS")
        print("  Running silent MSI install ...")
        run(f'msiexec /i "{msi_path}" /quiet /norestart ADDLOCAL=ALL')

    refresh_path()
    time.sleep(3)
    ver = node_version()
    if ver:
        ok(f"Node.js {ver} installed")
    else:
        warn("Node.js installed but 'node' not yet in PATH.")
        warn("Open a new PowerShell window and re-run this script.")

def step3_install_pnpm():
    step(3, TOTAL_STEPS, f"Installing pnpm v{PNPM_VERSION}")
    existing = pnpm_version()
    if existing:
        try:
            major = int(existing.split(".")[0])
            if major >= 8:
                ok(f"pnpm {existing} already installed — skipping")
                return
        except ValueError:
            pass

    npm_ver = npm_version()
    if not npm_ver:
        fail("npm not found. Node.js install may have failed or PATH not refreshed.")
        fail("Open a new PowerShell window and re-run this script.")
        sys.exit(1)

    print(f"  npm {npm_ver} found. Installing pnpm@{PNPM_VERSION} globally ...")
    run(f"npm install -g pnpm@{PNPM_VERSION}")
    refresh_path()
    time.sleep(2)
    ver = pnpm_version()
    if ver:
        ok(f"pnpm {ver} installed globally")
    else:
        warn("pnpm installed but not yet in PATH.")
        warn("Open a new PowerShell window and re-run, or run:  npm install -g pnpm")

def step4_pnpm_install():
    step(4, TOTAL_STEPS, "Installing npm packages via pnpm install")
    pnpm = shutil.which("pnpm") or "pnpm"
    node_modules = FRONTEND_DIR / "node_modules"
    if node_modules.exists() and (node_modules / ".modules.yaml").exists():
        warn("node_modules/ already exists — running pnpm install to sync ...")
    print("  Installing packages (this may take 2-4 minutes on first run) ...")
    run(f'"{pnpm}" install', cwd=FRONTEND_DIR)
    # Count installed packages from pnpm output
    result = run(f'"{pnpm}" list --depth=0', capture=True, cwd=FRONTEND_DIR, check=False)
    ok("All npm packages installed via pnpm")

def step5_create_env():
    step(5, TOTAL_STEPS, "Creating frontend/.env")
    if ENV_TARGET.exists():
        ok("frontend/.env already exists — skipping")
        return
    default_env = (
        "# GodsEye Frontend Environment Variables\n"
        "# Generated by setup_frontend.py\n\n"
        "# FastAPI backend base URL\n"
        "VITE_API_BASE_URL=http://localhost:8000\n\n"
        "# Mosquitto WebSocket port (optional — only if WS listener enabled)\n"
        "VITE_MQTT_WS_URL=ws://localhost:9001\n\n"
        "# React Query polling interval for live event stream (milliseconds)\n"
        "VITE_DASHBOARD_POLL_INTERVAL_MS=3000\n\n"
        "# App title shown in browser tab\n"
        "VITE_APP_TITLE=GodsEye Dashboard\n\n"
        "# Express BFF server port\n"
        "PORT=5173\n"
    )
    if ENV_EXAMPLE.exists():
        import shutil as _sh
        _sh.copy(ENV_EXAMPLE, ENV_TARGET)
        ok(f"Copied from {ENV_EXAMPLE.name}")
    else:
        ENV_TARGET.write_text(default_env)
        ok("Default frontend/.env created")
    warn("Review frontend/.env — update VITE_API_BASE_URL if backend runs on a different host.")

def step6_typecheck():
    step(6, TOTAL_STEPS, "Running TypeScript type-check")
    pnpm = shutil.which("pnpm") or "pnpm"
    result = run(f'"{pnpm}" typecheck', cwd=FRONTEND_DIR, check=False, capture=True)
    if result.returncode == 0:
        ok("TypeScript — no errors")
    else:
        errors = result.stdout.strip() + result.stderr.strip()
        warn(f"TypeScript check reported issues:")
        # Print first 20 lines only
        for line in errors.splitlines()[:20]:
            print(f"    {line}")
        warn("These may be pre-existing issues. Run 'pnpm typecheck' to review.")

def step7_production_build():
    step(7, TOTAL_STEPS, "Running production build (pnpm build)")
    pnpm = shutil.which("pnpm") or "pnpm"
    print("  Building frontend for production ...")
    result = run(f'"{pnpm}" build', cwd=FRONTEND_DIR, check=False, capture=True)
    dist_dir = FRONTEND_DIR / "dist"
    if result.returncode == 0 and dist_dir.exists():
        # Count files in dist
        file_count = sum(1 for _ in dist_dir.rglob("*") if _.is_file())
        ok(f"Production build successful — {file_count} files in frontend/dist/")
    else:
        warn("Production build reported issues. Run 'pnpm build' manually for details.")
        if result.stderr:
            for line in result.stderr.splitlines()[:15]:
                print(f"    {line}")

def step8_final_report():
    step(8, TOTAL_STEPS, "Setup Complete — Final Status Report")
    node_ver = node_version() or "not found"
    pnpm_ver = pnpm_version() or "not found"
    print(f"""
{CYAN}{'='*62}{RESET}
{BOLD}  GodsEye Frontend — Ready to Run{RESET}
{CYAN}{'='*62}{RESET}

{BOLD}Environment:{RESET}
  Node.js   : {node_ver}
  pnpm      : {pnpm_ver}
  Directory : {FRONTEND_DIR}

{BOLD}Start development server (hot-reload at http://localhost:5173):{RESET}
  cd {FRONTEND_DIR}
  pnpm dev

{BOLD}Production build:{RESET}
  pnpm build
  pnpm preview          (serve on http://localhost:4173)

{BOLD}Type-check:{RESET}
  pnpm typecheck

{BOLD}Run tests:{RESET}
  pnpm test

{BOLD}Lint:{RESET}
  pnpm lint

{BOLD}Environment variables:{RESET}
  Edit: frontend\\.env
  Key:  VITE_API_BASE_URL=http://localhost:8000  (FastAPI backend)

{BOLD}Start backend first:{RESET}
  cd {REPO_ROOT}
  venv\\Scripts\\activate
  python backend\\main.py

{BOLD}Dashboard components:{RESET}
  StatsGrid        — live threat statistics
  SecurityWidgets  — MITRE ATT&CK heat map
  LogViewer        — paginated event stream
  DeviceMap        — 3D SVG network topology
  OrgEventsChart   — hourly event histogram
  CliTerminal      — in-browser admin terminal

{CYAN}{'='*62}{RESET}
""")

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    banner()
    print(f"  Working directory : {REPO_ROOT}")
    print(f"  Frontend directory: {FRONTEND_DIR}")
    print(f"  Python executable : {sys.executable}\n")

    try:
        step1_check_prerequisites()
        step2_install_nodejs()
        step3_install_pnpm()
        step4_pnpm_install()
        step5_create_env()
        step6_typecheck()
        step7_production_build()
        step8_final_report()

    except KeyboardInterrupt:
        print(f"\n\n{YELLOW}Setup interrupted by user.{RESET}")
        sys.exit(1)
    except RuntimeError as e:
        print(f"\n{RED}Setup failed:{RESET} {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
