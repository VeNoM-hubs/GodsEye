"""
GodsEye — Backend Setup Script (Windows)
=========================================
AI-Driven IoT Network for Cyber-Physical Threat Detection
github.com/VeNoM-hubs/GodsEye

Run this script ONCE after cloning the repo:
    python setup_backend.py

What this script does (fully automated):
  1.  Checks Python version (3.10+ required)
  2.  Creates a virtual environment  (venv/)
  3.  Upgrades pip inside the venv
  4.  Installs all Python packages via pip
  5.  Downloads & installs PostgreSQL 16 silently (via winget / direct installer)
  6.  Creates the 'godseye' PostgreSQL database
  7.  Downloads & installs Mosquitto MQTT broker silently
  8.  Configures Mosquitto for anonymous local use and registers it as a Windows service
  9.  Downloads & installs Sysmon with the project config
  10. Creates config/config.yaml from the example template
  11. Initialises the database schema (tables + MITRE seed data)
  12. Runs a quick smoke-test to verify everything is working
  13. Prints a final status report

REQUIREMENTS BEFORE RUNNING:
  - Python 3.10+ already installed  (https://python.org/downloads)
  - Run PowerShell as Administrator  (right-click > Run as Administrator)
  - Internet connection
"""

import os
import sys
import subprocess
import platform
import shutil
import urllib.request
import zipfile
import tempfile
import time
import ctypes
from pathlib import Path

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------

REPO_ROOT        = Path(__file__).parent.resolve()
VENV_DIR         = REPO_ROOT / "venv"
VENV_PYTHON      = VENV_DIR / "Scripts" / "python.exe"
VENV_PIP         = VENV_DIR / "Scripts" / "pip.exe"
CONFIG_EXAMPLE   = REPO_ROOT / "config" / "config.yaml.example"
CONFIG_TARGET    = REPO_ROOT / "config" / "config.yaml"

# PostgreSQL 16 Windows x64 silent installer
PG_VERSION       = "16"
PG_INSTALLER_URL = (
    "https://get.enterprisedb.com/postgresql/"
    "postgresql-16.3-1-windows-x64.exe"
)
PG_INSTALL_DIR   = Path("C:/Program Files/PostgreSQL/16")
PG_BIN           = PG_INSTALL_DIR / "bin"
PSQL             = PG_BIN / "psql.exe"

# Mosquitto 2.x Windows x64 installer
MOSQUITTO_VERSION     = "2.0.18"
MOSQUITTO_INSTALLER_URL = (
    f"https://mosquitto.org/files/binary/win64/"
    f"mosquitto-{MOSQUITTO_VERSION}-install-windows-x64.exe"
)
MOSQUITTO_INSTALL_DIR = Path("C:/Program Files/mosquitto")
MOSQUITTO_CONF        = MOSQUITTO_INSTALL_DIR / "mosquitto.conf"

# Sysmon
SYSMON_ZIP_URL   = "https://download.sysinternals.com/files/Sysmon.zip"
SYSMON_INSTALL_DIR = Path("C:/Tools/Sysmon")
SYSMON_CONFIG    = REPO_ROOT / "monitoring" / "sysmon_config.xml"

# Pip packages — pinned for reproducibility
PIP_PACKAGES = [
    # Core framework
    "fastapi>=0.111.0,<1.0.0",
    "uvicorn[standard]>=0.30.0,<1.0.0",
    # Validation & config
    "pydantic>=2.5.0,<3.0.0",
    "pydantic-settings>=2.2.0,<3.0.0",
    "python-dotenv>=1.0.0,<2.0.0",
    "pyyaml>=6.0,<7.0",
    # Database
    "sqlalchemy>=2.0.30,<3.0.0",
    "psycopg2-binary>=2.9.9,<3.0.0",
    "alembic>=1.13.0,<2.0.0",
    # MQTT
    "paho-mqtt>=1.6.1,<3.0.0",
    # AI / ML
    "scikit-learn>=1.4.0,<2.0.0",
    "numpy>=1.26.0,<3.0.0",
    "pandas>=2.2.0,<3.0.0",
    "joblib>=1.3.0,<2.0.0",
    # API utilities
    "python-multipart>=0.0.9,<1.0.0",
    "httpx>=0.27.0,<1.0.0",
    "orjson>=3.10.0,<4.0.0",
    # Logging
    "python-json-logger>=2.0.7,<3.0.0",
    "loguru>=0.7.0,<1.0.0",
    # Security / auth
    "python-jose[cryptography]>=3.3.0,<4.0.0",
    "passlib[bcrypt]>=1.7.4,<2.0.0",
    "cryptography>=42.0.0,<45.0.0",
    # Scheduling
    "apscheduler>=3.10.0,<4.0.0",
    # Utilities
    "click>=8.1.0,<9.0.0",
    "rich>=13.7.0,<14.0.0",
    "python-dateutil>=2.9.0,<3.0.0",
    "pytz>=2024.1",
    "email-validator>=2.1.0,<3.0.0",
    # Testing
    "pytest>=8.1.0,<9.0.0",
    "pytest-asyncio>=0.23.0,<1.0.0",
    "pytest-cov>=5.0.0,<6.0.0",
    "faker>=25.0.0,<26.0.0",
    # Dev tools
    "black>=24.4.0,<25.0.0",
    "isort>=5.13.0,<6.0.0",
    "flake8>=7.0.0,<8.0.0",
    "mypy>=1.10.0,<2.0.0",
    "pre-commit>=3.7.0,<4.0.0",
]

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

def banner():
    print(f"""
{CYAN}{BOLD}
╔══════════════════════════════════════════════════════════════╗
║         GodsEye — Backend Setup Script (Windows)            ║
║   AI-Driven IoT ICS Cyber-Physical Threat Detection          ║
╚══════════════════════════════════════════════════════════════╝
{RESET}""")

def step(n, total, msg):
    print(f"\n{CYAN}[{n}/{total}]{RESET} {BOLD}{msg}{RESET}")

def ok(msg):
    print(f"  {GREEN}✔{RESET}  {msg}")

def warn(msg):
    print(f"  {YELLOW}⚠{RESET}  {msg}")

def fail(msg):
    print(f"  {RED}✘{RESET}  {msg}")

def run(cmd, check=True, capture=False, cwd=None):
    """Run a shell command; optionally capture output."""
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=capture,
        text=True,
        cwd=cwd or REPO_ROOT
    )
    if check and result.returncode != 0:
        raise RuntimeError(
            f"Command failed (exit {result.returncode}): {cmd}\n"
            f"{result.stderr}"
        )
    return result

def download(url, dest_path, label):
    """Download a file with a simple progress indicator."""
    print(f"  Downloading {label} ...", end="", flush=True)
    def reporthook(count, block_size, total_size):
        if total_size > 0:
            pct = min(int(count * block_size * 100 / total_size), 100)
            print(f"\r  Downloading {label} ... {pct}%", end="", flush=True)
    urllib.request.urlretrieve(url, dest_path, reporthook)
    print(f"\r  Downloading {label} ... {GREEN}done{RESET}        ")

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def program_exists(name):
    return shutil.which(name) is not None

def service_running(name):
    r = run(f'sc query "{name}"', check=False, capture=True)
    return "RUNNING" in r.stdout

def pg_running():
    return service_running("postgresql-x64-16") or service_running("postgresql")

def mosquitto_running():
    return service_running("mosquitto")

# ---------------------------------------------------------------------------
# STEPS
# ---------------------------------------------------------------------------

TOTAL_STEPS = 13

def step1_check_python():
    step(1, TOTAL_STEPS, "Checking Python version")
    major, minor = sys.version_info[:2]
    if major < 3 or (major == 3 and minor < 10):
        fail(f"Python 3.10+ required. Found: {major}.{minor}")
        fail("Download from https://python.org/downloads and re-run.")
        sys.exit(1)
    ok(f"Python {major}.{minor}.{sys.version_info.micro} — OK")
    if platform.system() != "Windows":
        fail("This script targets Windows only.")
        sys.exit(1)
    ok("OS: Windows — OK")
    if not is_admin():
        warn("Not running as Administrator.")
        warn("PostgreSQL and Mosquitto installs require admin rights.")
        warn("Re-run PowerShell as Administrator for full automation.")

def step2_create_venv():
    step(2, TOTAL_STEPS, "Creating Python virtual environment")
    if VENV_DIR.exists():
        warn(f"venv/ already exists — skipping creation")
    else:
        run(f'"{sys.executable}" -m venv "{VENV_DIR}"')
        ok(f"Virtual environment created at {VENV_DIR}")
    ok("Activate with:  venv\\Scripts\\activate")

def step3_upgrade_pip():
    step(3, TOTAL_STEPS, "Upgrading pip inside venv")
    run(f'"{VENV_PYTHON}" -m pip install --upgrade pip --quiet')
    result = run(f'"{VENV_PIP}" --version', capture=True)
    ok(f"pip {result.stdout.strip()}")

def step4_install_python_packages():
    step(4, TOTAL_STEPS, f"Installing {len(PIP_PACKAGES)} Python packages")
    print("  This may take 3-5 minutes on first run ...\n")
    packages_str = " ".join(f'"{p}"' for p in PIP_PACKAGES)
    run(
        f'"{VENV_PIP}" install {packages_str} --quiet --no-warn-script-location',
        check=True
    )
    ok(f"All {len(PIP_PACKAGES)} packages installed successfully")

def step5_install_postgresql():
    step(5, TOTAL_STEPS, "Installing PostgreSQL 16")
    if PSQL.exists() or program_exists("psql"):
        ok("PostgreSQL already installed — skipping")
        return
    if not is_admin():
        warn("Skipping PostgreSQL install (requires Administrator).")
        warn("Install manually: https://www.postgresql.org/download/windows/")
        return
    with tempfile.TemporaryDirectory() as tmp:
        installer = Path(tmp) / "pg_installer.exe"
        download(PG_INSTALLER_URL, installer, "PostgreSQL 16 installer")
        print("  Running silent install (this takes ~2 minutes) ...")
        run(
            f'"{installer}" '
            f'--mode unattended '
            f'--unattendedmodeui none '
            f'--superpassword postgres '
            f'--servicename postgresql '
            f'--servicepassword postgres '
            f'--serverport 5432 '
            f'--prefix "{PG_INSTALL_DIR}" '
            f'--datadir "{PG_INSTALL_DIR}\\data"'
        )
    ok(f"PostgreSQL 16 installed at {PG_INSTALL_DIR}")
    time.sleep(3)

def step6_create_database():
    step(6, TOTAL_STEPS, "Creating 'godseye' PostgreSQL database")
    psql_cmd = str(PSQL) if PSQL.exists() else "psql"
    env = os.environ.copy()
    env["PGPASSWORD"] = "postgres"
    # Check if DB already exists
    check = subprocess.run(
        f'"{psql_cmd}" -U postgres -lqt',
        shell=True, capture_output=True, text=True, env=env
    )
    if "godseye" in check.stdout:
        ok("Database 'godseye' already exists — skipping")
        return
    if not pg_running():
        warn("PostgreSQL service not running — attempting to start ...")
        run('net start postgresql-x64-16', check=False)
        run('net start postgresql', check=False)
        time.sleep(3)
    result = subprocess.run(
        f'"{psql_cmd}" -U postgres -c "CREATE DATABASE godseye;"',
        shell=True, capture_output=True, text=True, env=env
    )
    if result.returncode == 0:
        ok("Database 'godseye' created")
    else:
        warn(f"Could not create database automatically: {result.stderr.strip()}")
        warn("Create it manually:  psql -U postgres -c \"CREATE DATABASE godseye;\"")

def step7_install_mosquitto():
    step(7, TOTAL_STEPS, "Installing Mosquitto MQTT Broker")
    if MOSQUITTO_INSTALL_DIR.exists() or program_exists("mosquitto"):
        ok("Mosquitto already installed — skipping")
        return
    if not is_admin():
        warn("Skipping Mosquitto install (requires Administrator).")
        warn(f"Install manually: https://mosquitto.org/download/")
        return
    with tempfile.TemporaryDirectory() as tmp:
        installer = Path(tmp) / "mosquitto_installer.exe"
        download(MOSQUITTO_INSTALLER_URL, installer, f"Mosquitto {MOSQUITTO_VERSION}")
        print("  Running silent install ...")
        run(f'"{installer}" /S')
    ok(f"Mosquitto installed at {MOSQUITTO_INSTALL_DIR}")
    time.sleep(2)

def step8_configure_mosquitto():
    step(8, TOTAL_STEPS, "Configuring Mosquitto for GodsEye")
    if not MOSQUITTO_INSTALL_DIR.exists():
        warn("Mosquitto not found — skipping configuration")
        return
    conf_content = (
        "# GodsEye Mosquitto Configuration\n"
        "listener 1883\n"
        "allow_anonymous true\n"
        "log_type error\n"
        "log_type warning\n"
        "log_type notice\n"
        "log_type information\n"
        "persistence true\n"
        f"persistence_location {MOSQUITTO_INSTALL_DIR}/\n"
    )
    try:
        MOSQUITTO_CONF.write_text(conf_content)
        ok(f"Mosquitto config written to {MOSQUITTO_CONF}")
    except PermissionError:
        warn(f"Cannot write to {MOSQUITTO_CONF} (needs admin). Skipping.")
    # Register and start service
    if not mosquitto_running():
        run(f'"{MOSQUITTO_INSTALL_DIR}\\mosquitto.exe" install', check=False)
        run('net start mosquitto', check=False)
        time.sleep(2)
    if mosquitto_running():
        ok("Mosquitto service is RUNNING on port 1883")
    else:
        warn("Mosquitto service not started. Start manually: net start mosquitto")

def step9_install_sysmon():
    step(9, TOTAL_STEPS, "Installing Sysmon (endpoint telemetry)")
    if program_exists("sysmon64") or (SYSMON_INSTALL_DIR / "Sysmon64.exe").exists():
        ok("Sysmon already installed — skipping")
        return
    if not is_admin():
        warn("Skipping Sysmon install (requires Administrator).")
        return
    SYSMON_INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        zip_path = Path(tmp) / "Sysmon.zip"
        download(SYSMON_ZIP_URL, zip_path, "Sysmon")
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(SYSMON_INSTALL_DIR)
    sysmon_exe = SYSMON_INSTALL_DIR / "Sysmon64.exe"
    if SYSMON_CONFIG.exists():
        run(
            f'"{sysmon_exe}" -accepteula -i "{SYSMON_CONFIG}"',
            check=False
        )
        ok(f"Sysmon installed with GodsEye config from {SYSMON_CONFIG}")
    else:
        run(f'"{sysmon_exe}" -accepteula -i', check=False)
        warn("monitoring/sysmon_config.xml not found — Sysmon installed with default config")
        warn("Add your sysmon_config.xml and run: sysmon64 -c monitoring/sysmon_config.xml")

def step10_create_config():
    step(10, TOTAL_STEPS, "Creating config/config.yaml")
    CONFIG_TARGET.parent.mkdir(parents=True, exist_ok=True)
    if CONFIG_TARGET.exists():
        ok("config/config.yaml already exists — skipping")
        return
    if CONFIG_EXAMPLE.exists():
        shutil.copy(CONFIG_EXAMPLE, CONFIG_TARGET)
        ok(f"Copied from {CONFIG_EXAMPLE.name}")
    else:
        # Write a sensible default config
        default_config = """\
# GodsEye Configuration
# Generated by setup_backend.py

database:
  host: localhost
  port: 5432
  name: godseye
  user: postgres
  password: postgres

mqtt:
  broker_host: localhost
  broker_port: 1883
  topic_prefix: godseye
  qos: 1

security:
  secret_key: CHANGE_ME_generate_with_python_secrets_token_hex_32
  max_failed_attempts: 3
  failed_attempt_window_seconds: 300
  normal_access_hours_start: 6
  normal_access_hours_end: 22
  require_multi_factor: true
  alert_threshold: 0.7
  decoy_cards:
    - FAKE_CARD_001
    - FAKE_CARD_002
    - DECOY_999
  decoy_fingerprints:
    - FAKE_FP_001
    - FAKE_FP_002
  known_locations:
    - Server Room A
    - Control Room
    - Main Entrance

api:
  host: 0.0.0.0
  port: 8000
  debug: false
  cors_origins:
    - http://localhost:5173
    - http://localhost:3000

logging:
  level: INFO
  format: json
  file: logs/godseye.log

ml:
  model_path: ml_models/isolation_forest.pkl
  contamination: 0.1
  retrain_interval_hours: 24
"""
        CONFIG_TARGET.write_text(default_config)
        ok("Default config/config.yaml created")
    warn("IMPORTANT: Edit config/config.yaml — set DB password and SECRET_KEY before running.")

def step11_init_database():
    step(11, TOTAL_STEPS, "Initialising database schema + seeding MITRE data")
    db_init_script = REPO_ROOT / "backend" / "db_init.py"
    seed_script    = REPO_ROOT / "tests"   / "seed_database.py"
    db_setup_sql   = REPO_ROOT / "database" / "setup_postgres.sql"
    if not pg_running():
        warn("PostgreSQL not running — skipping DB init")
        warn("Start PostgreSQL and run manually:  python backend\\db_init.py")
        return
    env = os.environ.copy()
    env["PGPASSWORD"] = "postgres"
    # Try SQL-based setup first
    if db_setup_sql.exists():
        psql_cmd = str(PSQL) if PSQL.exists() else "psql"
        result = subprocess.run(
            f'"{psql_cmd}" -U postgres -d godseye -f "{db_setup_sql}"',
            shell=True, capture_output=True, text=True, env=env
        )
        if result.returncode == 0:
            ok("Database schema created via setup_postgres.sql")
        else:
            warn(f"SQL setup returned: {result.stderr.strip()[:200]}")
    elif db_init_script.exists():
        result = subprocess.run(
            f'"{VENV_PYTHON}" -m backend.db_init',
            shell=True, capture_output=True, text=True, cwd=REPO_ROOT
        )
        if result.returncode == 0:
            ok("Database initialised via backend/db_init.py")
        else:
            warn(f"db_init.py returned: {result.stderr.strip()[:200]}")
    else:
        warn("No DB init script found — schema must be created manually.")
        warn("Run: psql -U postgres -d godseye -f database/setup_postgres.sql")
    # Seed MITRE data
    if seed_script.exists():
        result = subprocess.run(
            f'"{VENV_PYTHON}" "{seed_script}"',
            shell=True, capture_output=True, text=True, cwd=REPO_ROOT
        )
        if result.returncode == 0:
            ok("Database seeded with MITRE ATT&CK for ICS data")
        else:
            warn(f"Seed script warning: {result.stderr.strip()[:200]}")

def step12_smoke_test():
    step(12, TOTAL_STEPS, "Running smoke tests")
    # Test 1: Python imports
    imports = [
        "fastapi", "uvicorn", "pydantic", "sqlalchemy",
        "psycopg2", "paho.mqtt.client", "sklearn", "numpy",
        "pandas", "loguru", "jose", "passlib"
    ]
    failed_imports = []
    for pkg in imports:
        result = subprocess.run(
            f'"{VENV_PYTHON}" -c "import {pkg}"',
            shell=True, capture_output=True, text=True
        )
        if result.returncode != 0:
            failed_imports.append(pkg)
    if failed_imports:
        fail(f"Import failures: {', '.join(failed_imports)}")
        fail("Run:  .\\venv\\Scripts\\activate  then  pip install <package>")
    else:
        ok(f"All {len(imports)} critical imports verified")
    # Test 2: MQTT broker reachability
    mqtt_test = subprocess.run(
        f'"{VENV_PYTHON}" -c "'
        "import paho.mqtt.client as mqtt, time\n"
        "c=mqtt.Client()\n"
        "c.connect_async('localhost',1883)\n"
        "c.loop_start()\n"
        "time.sleep(1)\n"
        "c.loop_stop()\n"
        "print('mqtt_ok')"
        '"',
        shell=True, capture_output=True, text=True, timeout=10
    )
    if "mqtt_ok" in mqtt_test.stdout:
        ok("MQTT broker reachable on localhost:1883")
    else:
        warn("MQTT broker not reachable — start Mosquitto: net start mosquitto")

def step13_final_report():
    step(13, TOTAL_STEPS, "Setup Complete — Final Status Report")
    print(f"""
{CYAN}{'='*62}{RESET}
{BOLD}  GodsEye Backend — Ready to Run{RESET}
{CYAN}{'='*62}{RESET}

{BOLD}Activate the virtual environment:{RESET}
  cd {REPO_ROOT}
  venv\\Scripts\\activate

{BOLD}Start the full backend:{RESET}
  python backend\\main.py

{BOLD}Start API server only:{RESET}
  python -m backend.api_server
  Swagger UI: http://localhost:8000/docs

{BOLD}Run master test suite:{RESET}
  python tests\\master_test.py

{BOLD}Run unit tests:{RESET}
  pytest tests\\ -v

{BOLD}MQTT broker status:{RESET}
  sc query mosquitto

{BOLD}PostgreSQL status:{RESET}
  sc query postgresql-x64-16

{BOLD}Next steps:{RESET}
  1. Edit config\\config.yaml  — set your DB password and SECRET_KEY
  2. Flash your ESP32 firmware from  iot\\firmware\\
  3. Set Mosquitto broker IP in config.yaml if ESP32 is on another device
  4. Start frontend: cd frontend && pnpm dev

{CYAN}{'='*62}{RESET}
""")

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    banner()
    print(f"  Working directory : {REPO_ROOT}")
    print(f"  Python executable : {sys.executable}")
    print(f"  Platform          : {platform.platform()}\n")

    try:
        step1_check_python()
        step2_create_venv()
        step3_upgrade_pip()
        step4_install_python_packages()
        step5_install_postgresql()
        step6_create_database()
        step7_install_mosquitto()
        step8_configure_mosquitto()
        step9_install_sysmon()
        step10_create_config()
        step11_init_database()
        step12_smoke_test()
        step13_final_report()

    except KeyboardInterrupt:
        print(f"\n\n{YELLOW}Setup interrupted by user.{RESET}")
        sys.exit(1)
    except RuntimeError as e:
        print(f"\n{RED}Setup failed:{RESET} {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
